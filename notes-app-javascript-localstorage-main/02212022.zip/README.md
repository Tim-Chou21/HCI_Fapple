# notes-app-javascript-localstorage
A Notes App built with vanilla JavaScript and Local Storage.

This is taken from my YouTube video tutorial at:
https://youtu.be/01YKQmia2Jw
